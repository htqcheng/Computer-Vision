nIters = 1000
tol = 0.42
Thres = 100
